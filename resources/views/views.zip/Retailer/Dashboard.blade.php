@extends('layout')
@section('content')

<h2>Welcome to Retailer Dashboard</h2>

@endsection()