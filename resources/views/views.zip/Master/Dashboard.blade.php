@extends('layout')
@section('content')

<h2>Master Login </h2>


@endsection()