let totalAmount = 24950 + (24950 * (5 / 100));
    let vatAmount = 24950 * (5 / 100);
    console.log("vatAmount "+vatAmount.toFixed(2));
    console.log("totalAmount "+totalAmount.toFixed(2));