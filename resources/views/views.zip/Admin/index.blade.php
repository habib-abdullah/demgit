<h2>Welcome to master admin</h2>
<a href="{{url('Logout')}}">logout</a>







 <!-- jQuery -->
 <script src="{{url('public/plugins/jquery/jquery.min.js')}}"></script>

<script>
$(document).ready(function() {
// alert('ready');
});

// function Logout(){
//   $.get("{{url('Logout')}}",function(data){
//     console.log(data);
//   });
// }
</script>
