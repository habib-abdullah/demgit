@extends('layout')
@section('content')

<h2>Welcome to Distributor Dashboard</h2>

@endsection()